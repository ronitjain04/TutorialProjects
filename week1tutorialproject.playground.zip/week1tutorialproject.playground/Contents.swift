import UIKit

// Variables
var attendence = 1
attendence = 2

// Constants
let immutableString = "This cannot be changed"
// immutableString = "Changed string"

// immutableString = "Attempt to change" // This will cause an error

// Variable Declaration
// var age = 25
var age: Int = 25
//var name = "Ronit"
var name: String = "Ronit"

// Doubles and Floats
var pi: Double = 3.14159
var temperature: Float = 36.6

// Booleans
let isSwiftAwesome: Bool = true

// Strings
var greeting: String = "Hello, Swift!"

//Conditionals
var number = 5

if number > 5 {
    print("Number is greater than 5")
} else if number < 5 {
    print("Number is less than 5")
} else {
    print("Number is equal to 5")
}

// Arithmetic Operators
let sum = 5 + 3
let difference = 10 - 4
let product = 2 * 3
let quotient = 10 / 2
let remainder = 9 % 2

// Comparison Operators
let isEqual = (5 == 5) // true
let isNotEqual = (5 != 3) // true
let isGreater = (5 > 3) // true
let isLessOrEqual = (3 <= 5) // true

