import UIKit

// Variables
// Creating a variable named aNum and set it to 1
// Print aNum to show that it is attatched to 1
// Set aNum to 2 to show that it is mutable
// Print aNum to show that it has changed to 2
var aNum = 1
print(aNum)
aNum = 2
print(aNum)

// Constants
// Create a constant named immutableNum
// Print immutableNum to show that it has been assigned the number
// Try to set it to a different number and show the error, explain how it cannot be changed
let immutableNum = 3
print(immutableNum)
// immutableString = "Changed string"

// Variable Declaration
/*
 Create a variable named age and set it to a number and show how it implicitly becomes a Int.
 Then to the same var add the explicit version of the num to show how it can be set to a certain type
 Do the same thing with another type to show it works for all data types
 */
// var age = 25
var age: Int = 25
//var name = "Ronit"
var name: String = "Ronit"

// Doubles and Floats
/*
 Create a variable for a double and explain that it
 Create a variable for a float and explain it
 Explain the difference between a float and a double
 Float
 Precision: A Float is a 32-bit floating-point number, which provides about 6 to 7 decimal digits of precision.
 Memory Usage: Since it uses 32 bits, a Float occupies less memory compared to a Double.
 Use Case: Use Float when you need to save memory and when the precision provided by Float is sufficient for your calculations. This is typically in scenarios where memory is constrained, or when dealing with large arrays of floating-point numbers where the reduced precision is acceptable.
 Double
 Precision: A Double is a 64-bit floating-point number, which offers about 15 to 16 decimal digits of precision.
 Memory Usage: A Double uses 64 bits, meaning it takes up more memory than a Float.
 Use Case: Use Double when you need higher precision in your calculations. It is the default choice for floating-point numbers in Swift because it provides more accurate results and reduces the risk of rounding errors in complex mathematical operations.
 */
var pi: Double = 3.14159
var temperature: Float = 36.6

// Booleans
/*
 Create a variable and assign it to a boolean, explain what a boolean is and what it is used for
 */
var isSwiftAwesome: Bool = true

// Strings
/*
 Create a variable and assign it to a string, explain what strings are used for
 */
var greeting: String = "Hello, Swift!"

//Conditionals
/*
 Create a variable and used if statements to show how conditionals work.
 Start by creating the if statement, move to the else if, and finish with the else to show how to fully use conditionals
 */
var number = 5

if number > 5 {
    print("Number is greater than 5")
} else if number < 5 {
    print("Number is less than 5")
} else {
    print("Number is equal to 5")
}

// Arithmetic Operators
/*
 Show all arithmetic operators and explain what they all do and how to implement them
 */
let sum = 5 + 3
let difference = 10 - 4
let product = 2 * 3
let quotient = 10 / 2
let remainder = 9 % 2

// Comparison Operators
/*
 Show all comparison operaters and exlain what they do and how to implemenet them.
 */
let isEqual = (5 == 5) // true
let isNotEqual = (5 != 3) // true
let isGreater = (5 > 3) // true
let isLessOrEqual = (3 <= 5) // true

